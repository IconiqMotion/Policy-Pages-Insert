<!doctype html>
<html lang="he" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>מדיניות החזרים וביטולים – {{BUSINESS_NAME}}</title>
  <meta name="robots" content="{{INDEX_POLICY|index,follow}}">
  <link rel="canonical" href="{{SITE_URL}}/returns">
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;line-height:1.8;margin:0;color:#1a1a1a;background:#fff}
    .wrap{max-width:900px;margin:0 auto;padding:24px}
    h1,h2,h3{line-height:1.3;margin:24px 0 12px}
    h1{font-size:clamp(26px,4vw,34px)}
    h2{font-size:clamp(20px,3vw,26px)}
    h3{font-size:clamp(18px,2.4vw,22px)}
    a{color:#0b69c7}
    nav.breadcrumbs{font-size:.9em;margin:16px 0;color:#666}
    ul{margin:0 0 12px 0;padding-inline-start:22px}
    footer{margin-top:36px;border-top:1px solid #eee;padding-top:12px;color:#666;font-size:.95em}
  </style>
</head>
<body>
  <div class="wrap" role="main" id="main">
    <nav class="breadcrumbs" aria-label="ניווט משני">דף הבית › מדיניות החזרים וביטולים</nav>
    <h1>מדיניות החזרים וביטולים – {{BUSINESS_NAME}}</h1>
    <p class="meta">עודכן לאחרונה: {{EFFECTIVE_DATE}}</p>

    <h2>1. ביטול עסקה</h2>
    <ul>
      <li>ניתן לבטל רכישה בתוך {{CANCEL_WITHIN_DAYS|14}} ימים ממועד קבלת המוצר, בהתאם לחוק.</li>
      <li>החזר כספי יינתן בניכוי דמי ביטול של עד 5% או 100 ₪ (הנמוך מביניהם), אלא אם נקבע אחרת בדין.</li>
    </ul>

    <h2>2. החזרת מוצרים</h2>
    <ul>
      <li>יש להחזיר מוצר כשהוא חדש, באריזתו המקורית וללא שימוש.</li>
      <li>עלות המשלוח חזרה תחול על הלקוח/ה, אלא אם נמסר פגם מהותי.</li>
    </ul>

    <h2>3. מוצרים שאינם בני החזרה</h2>
    <ul>
      <li>מוצרים בהתאמה אישית/תפירה אישית.</li>
      <li>מוצרים מתכלים (כגון קוסמטיקה שנפתחה).</li>
      <li>מוצרים שנעשה בהם שימוש החורג מבדיקה סבירה.</li>
    </ul>

    <h2>4. אופן ההחזר</h2>
    <ul>
      <li>ההחזר יבוצע לאמצעי התשלום שבו בוצעה העסקה, בתוך {{REFUND_DAYS|7}} ימי עסקים ממועד קבלת המוצר חזרה.</li>
    </ul>

    <h2>5. פנייה לעניין ביטול</h2>
    <p>לצורך ביטול/החזרה אנא פנו אלינו: <a href="mailto:{{EMAIL}}">{{EMAIL}}</a> | <a href="tel:{{PHONE}}">{{PHONE}}</a>.</p>

    <footer>© {{BUSINESS_NAME}} · {{SITE_URL}}</footer>
  </div>
</body>
</html>
