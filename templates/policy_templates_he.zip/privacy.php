<!doctype html>
<html lang="he" dir="rtl">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>מדיניות פרטיות – {{BUSINESS_NAME}}</title>
  <meta name="robots" content="{{INDEX_POLICY|index,follow}}">
  <link rel="canonical" href="{{SITE_URL}}/privacy">
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Helvetica,Arial;line-height:1.8;margin:0;color:#1a1a1a;background:#fff}
    .wrap{max-width:900px;margin:0 auto;padding:24px}
    h1,h2,h3{line-height:1.3;margin:24px 0 12px}
    h1{font-size:clamp(26px,4vw,34px)}
    h2{font-size:clamp(20px,3vw,26px)}
    h3{font-size:clamp(18px,2.4vw,22px)}
    a{color:#0b69c7}
    .meta{color:#666;font-size:.95em;margin-top:8px}
    nav.breadcrumbs{font-size:.9em;margin:16px 0;color:#666}
    .note{background:#f7fafc;border:1px solid #e1e8f0;padding:12px 14px;border-radius:10px;margin:12px 0}
    ul{margin:0 0 12px 0;padding-inline-start:22px}
    .sr-only{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);border:0}
    footer{margin-top:36px;border-top:1px solid #eee;padding-top:12px;color:#666;font-size:.95em}
  </style>
</head>
<body>
  <a class="sr-only" href="#main">דלג לתוכן הראשי</a>
  <div class="wrap" role="main" id="main">
    <nav class="breadcrumbs" aria-label="ניווט משני">דף הבית › מדיניות פרטיות</nav>
    <header>
      <h1>מדיניות פרטיות – {{BUSINESS_NAME}}</h1>
      <p class="meta">עודכן לאחרונה: {{EFFECTIVE_DATE}}</p>
    </header>

    <p>ב{{BUSINESS_NAME}} ({{SITE_URL}}) אנו רואים חשיבות רבה בהגנה על פרטיותך. מסמך זה מסביר אילו נתונים אנו אוספים, כיצד אנו משתמשים בהם, כיצד אנו שומרים על אבטחתם, ומהן זכויותיך לפי הדין החל (חוקי ישראל והרגולציות הרלוונטיות, לרבות ה־GDPR ככל שחל).</p>

    <h2 id="what-we-collect">1. אילו נתונים אנו אוספים</h2>
    <ul>
      <li><strong>מידע מזהה</strong>: שם, דוא״ל, טלפון, כתובת והעדפות שציינת.</li>
      <li><strong>מידע תשלום</strong>: פרטי סליקה מעובדים דרך ספקים מורשים; איננו שומרים מספרי כרטיס מלאים בשרתינו.</li>
      <li><strong>מידע טכני</strong>: כתובת IP, סוג דפדפן/מכשיר, מערכת הפעלה, הפניות (referrer).</li>
      <li><strong>מידע שימוש</strong>: עמודים שנצפו, אירועי קליקים, משך שהייה, תיעוד תקלות.</li>
      <li><strong>קוקיז/פיקסלים</strong>: לצורך תפעול האתר, סטטיסטיקה, ושיווק בכפוף להסכמה.</li>
    </ul>

    <h2 id="why">2. למה אנו משתמשים בנתונים</h2>
    <ul>
      <li>הפעלה, אבטחה ותחזוקה של האתר והשירותים.</li>
      <li>טיפול בהזמנות/פניות ותמיכה.</li>
      <li>שיפור חוויית המשתמש והתאמת תוכן.</li>
      <li>מדידה וניתוח (Analytics) – נתונים מצטברים ואנונימיים ככל האפשר.</li>
      <li>עמידה בחובות חוקיות וציות לרשויות מוסמכות.</li>
      <li>שיווק בכפוף להסכמתך, עם אפשרות הסרה בכל עת.</li>
    </ul>

    <h2 id="cookies">3. שימוש בקוקיז וטכנולוגיות דומות</h2>
    <p>אנו משתמשים בקוקיז (כולל first/third-party) ופיקסלים (כגון Google Analytics ו‑Meta Pixel) לצורך תפעול, מדידה והתאמה אישית. באפשרותך לנהל העדפות באמצעות <strong>פופ‑אפ ניהול העוגיות</strong> באתר או דרך הגדרות הדפדפן. ניתן למצוא הרחבה במדיניות העוגיות בתוך מסמך זה.</p>

    <h2 id="third-parties">4. שיתוף מידע עם צדדים שלישיים</h2>
    <ul>
      <li>ספקי תשתית וטכנולוגיה (אחסון, תחזוקה, הגנת מידע).</li>
      <li>כלי אנליטיקה ופרסום (Google/Meta/וכו׳) במסגרת תנאיהם.</li>
      <li>גורמים פיננסיים לסליקה.</li>
      <li>רשויות מוסמכות כשנדרש על פי חוק.</li>
    </ul>

    <h2 id="security">5. אבטחת מידע ושמירתו</h2>
    <p>אנו מיישמים אמצעי אבטחה סבירים (כולל הצפנת TLS/SSL, בקרות גישה וגיבויים). אף שאין אבטחה מוחלטת, אנו פועלים לצמצום סיכונים, להגבלת גישה לפי צורך ולזמני שמירת מידע תואמי מטרה.</p>

    <h2 id="your-rights">6. הזכויות שלך</h2>
    <ul>
      <li>זכות לעיין ולקבל עותק מן המידע עליך.</li>
      <li>זכות לתקן/לעדכן מידע שגוי.</li>
      <li>זכות לבקש מחיקה (“Right to be forgotten”) בכפוף לדין.</li>
      <li>זכות להתנגד לשימוש לשיווק ישיר ולהסיר הסכמה.</li>
      <li>זכות לניידות מידע בפורמט קריא.</li>
    </ul>

    <h2 id="contact">7. יצירת קשר</h2>
    <p>לכל שאלה בנושא פרטיות: דוא״ל <a href="mailto:{{EMAIL}}">{{EMAIL}}</a>, טלפון <a href="tel:{{PHONE}}">{{PHONE}}</a>, כתובת: {{ADDRESS}}.</p>

    <h2 id="updates">8. עדכונים למדיניות</h2>
    <p>אנו עשויים לעדכן מסמך זה מעת לעת. תאריך העדכון האחרון מופיע בראש העמוד.</p>

    <footer>© {{BUSINESS_NAME}} · {{SITE_URL}}</footer>
  </div>
</body>
</html>
